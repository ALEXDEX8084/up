﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EventPracticaZM.Classes;

namespace EventPracticaZM.Pages
{
    /// <summary>
    /// Логика взаимодействия для ZuriPage.xaml
    /// </summary>
    public partial class ZuriPage : Page
    {
        public ZuriPage()
        {
            InitializeComponent();
            ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.ToList();
        }

        private void editclient_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new ZuriEditAddPage((Jury)ListClients.SelectedItem));
        }

        private void DeleteClient_Click(object sender, RoutedEventArgs e)
        {
            var personForRemoving = ListClients.SelectedItems.Cast<Jury>().ToList();
            var resMessage = MessageBox.Show("Удалить запись?", "Подтверждение",
             MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (resMessage == MessageBoxResult.Yes)
            {
                try
                {
                    ConferenceEntities.GetContext().Jury.RemoveRange(personForRemoving);
                    ConferenceEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Данный клиент арендует помещение", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Pages.ZuriEditAddPage(null));
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (CmbFiltrSort.Text == "По ФИО")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.Where(x => x.FIO.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
            if (CmbFiltrSort.Text == "По номеру телефона")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.Where(x => x.Phone.ToString().ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
            if (CmbFiltrSort.Text == "По дате рождения")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.Where(x => x.DateOfBirth.ToString().Contains(TxtSearch.Text.ToLower())).ToList();
            if (CmbFiltrSort.Text == "По почте")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.Where(x => x.Email.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

        private void CmbFiltrSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (RbDown.IsChecked == true)
            {
                if (CmbFiltrSort.Text == "По ФИО")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderByDescending(x => x.FIO).ToList();
                if (CmbFiltrSort.Text == "По номеру телефона")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderByDescending(x => x.Phone).ToList();
                if (CmbFiltrSort.Text == "По дате рождения")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderByDescending(x => x.DateOfBirth).ToList();
                if (CmbFiltrSort.Text == "По почте")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderByDescending(x => x.Email).ToList();
            }
            if (RbUp.IsChecked == true)
            {
                if (CmbFiltrSort.Text == "По ФИР")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderBy(x => x.FIO).ToList();
                if (CmbFiltrSort.Text == "По номеру телефона")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderBy(x => x.Phone).ToList();
                if (CmbFiltrSort.Text == "По дате рождения")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderBy(x => x.DateOfBirth).ToList();
                if (CmbFiltrSort.Text == "По почте")
                    ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderBy(x => x.Email).ToList();
            }
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            if (CmbFiltrSort.Text == "По ФИО")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderBy(x => x.FIO).ToList();
            if (CmbFiltrSort.Text == "По телефону")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderBy(x => x.Phone).ToList();
            if (CmbFiltrSort.Text == "По дате рождения")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderBy(x => x.DateOfBirth).ToList();
            if (CmbFiltrSort.Text == "По почте")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderBy(x => x.Email).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            if (CmbFiltrSort.Text == "По ФИО")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderByDescending(x => x.FIO).ToList();
            if (CmbFiltrSort.Text == "По телефону")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderByDescending(x => x.Phone).ToList();
            if (CmbFiltrSort.Text == "По дате рождения")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderByDescending(x => x.DateOfBirth).ToList();
            if (CmbFiltrSort.Text == "По почте")
                ListClients.ItemsSource = ConferenceEntities.GetContext().Jury.OrderByDescending(x => x.Email).ToList();
        }
    }
}
